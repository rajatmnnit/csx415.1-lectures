library(testthat)
library(optigrab)

test_check("optigrab")
